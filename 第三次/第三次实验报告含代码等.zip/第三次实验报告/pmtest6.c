#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>

#define PAGE_SIZE 4096            // 页大小4KB
#define PAGE_TABLE_ENTRIES 1024   // 每个页表包含1024个页表项
#define PAGE_DIRECTORY_ENTRIES 1024  // 页目录包含1024个页目录项
#define MEMORY_SIZE PAGE_DIRECTORY_ENTRIES * PAGE_TABLE_ENTRIES * PAGE_SIZE  // 总物理内存大小

// 页表项 (PTE)
typedef struct {
    uint32_t present   : 1;   // 页是否存在
    uint32_t rw        : 1;   // 读/写标志
    uint32_t user      : 1;   // 用户模式/内核模式标志
    uint32_t reserved  : 9;   // 保留位
    uint32_t frame     : 20;  // 物理页框地址
} PTE;

// 页目录项 (PDE)
typedef struct {
    uint32_t present   : 1;   // 页表是否存在
    uint32_t rw        : 1;   // 读/写标志
    uint32_t user      : 1;   // 用户模式/内核模式标志
    uint32_t reserved  : 9;   // 保留位
    uint32_t frame     : 20;  // 页表的物理页框地址
} PDE;

// 页表
typedef struct {
    PTE entries[PAGE_TABLE_ENTRIES];
} PageTable;

// 页目录
typedef struct {
    PDE entries[PAGE_DIRECTORY_ENTRIES];
} PageDirectory;

// 模拟物理内存
uint8_t physical_memory[MEMORY_SIZE];

// 分配物理内存页的标记（0表示未分配，1表示已分配）
int allocated_pages[PAGE_DIRECTORY_ENTRIES * PAGE_TABLE_ENTRIES] = {0};

// 分配物理页
uint32_t alloc_page() {
    for (int i = 0; i < PAGE_DIRECTORY_ENTRIES * PAGE_TABLE_ENTRIES; i++) {
        if (!allocated_pages[i]) {
            allocated_pages[i] = 1;  // 标记为已分配
            return i;  // 返回物理页框号
        }
    }
    return -1;  // 没有空闲页
}

// 释放物理页
void free_page(uint32_t page_frame) {
    allocated_pages[page_frame] = 0;
}

// 分配页表
PageTable *alloc_page_table() {
    PageTable *pt = (PageTable *)malloc(sizeof(PageTable));
    for (int i = 0; i < PAGE_TABLE_ENTRIES; i++) {
        pt->entries[i].present = 0;  // 初始化页表项
    }
    return pt;
}

// 分配页目录
PageDirectory *alloc_page_directory() {
    PageDirectory *pd = (PageDirectory *)malloc(sizeof(PageDirectory));
    for (int i = 0; i < PAGE_DIRECTORY_ENTRIES; i++) {
        pd->entries[i].present = 0;  // 初始化页目录项
    }
    return pd;
}

// 将虚拟地址映射到物理地址
void map_page(PageDirectory *pd, uint32_t virtual_address, uint32_t physical_address) {
    uint32_t page_directory_index = (virtual_address >> 22) & 0x3FF;  // 高10位为页目录索引
    uint32_t page_table_index = (virtual_address >> 12) & 0x3FF;      // 中间10位为页表索引

    // 如果页目录项不存在，分配新的页表
    if (!pd->entries[page_directory_index].present) {
        PageTable *pt = alloc_page_table();
        uint32_t pt_frame = alloc_page();
        pd->entries[page_directory_index].present = 1;
        pd->entries[page_directory_index].frame = pt_frame;  // 设置页表的物理地址
        printf("Allocated page table for page directory index %d\n", page_directory_index);
    }

    // 获取页表的物理地址
    PageTable *pt = (PageTable *)(physical_memory + (pd->entries[page_directory_index].frame * PAGE_SIZE));

    // 在页表中设置页表项
    pt->entries[page_table_index].present = 1;
    pt->entries[page_table_index].frame = physical_address / PAGE_SIZE;
    printf("Mapped virtual address 0x%x to physical address 0x%x\n", virtual_address, physical_address);
}

// 释放虚拟地址到物理地址的映射
void unmap_page(PageDirectory *pd, uint32_t virtual_address) {
    uint32_t page_directory_index = (virtual_address >> 22) & 0x3FF;  // 高10位为页目录索引
    uint32_t page_table_index = (virtual_address >> 12) & 0x3FF;      // 中间10位为页表索引

    // 查找页目录项
    if (!pd->entries[page_directory_index].present) {
        printf("Error: Page directory entry not present for virtual address 0x%x\n", virtual_address);
        return;
    }

    // 获取页表
    PageTable *pt = (PageTable *)(physical_memory + (pd->entries[page_directory_index].frame * PAGE_SIZE));

    // 查找页表项
    if (!pt->entries[page_table_index].present) {
        printf("Error: Page table entry not present for virtual address 0x%x\n", virtual_address);
        return;
    }

    // 释放物理页
    free_page(pt->entries[page_table_index].frame);
    pt->entries[page_table_index].present = 0;  // 清空页表项
    printf("Unmapped virtual address 0x%x\n", virtual_address);
}

// 虚拟地址转换为物理地址
int virtual_to_physical(PageDirectory *pd, uint32_t virtual_address, uint32_t *physical_address) {
    uint32_t page_directory_index = (virtual_address >> 22) & 0x3FF;  // 高10位为页目录索引
    uint32_t page_table_index = (virtual_address >> 12) & 0x3FF;      // 中间10位为页表索引
    uint32_t page_offset = virtual_address & 0xFFF;                   // 低12位为页内偏移

    // 查找页目录项
    if (!pd->entries[page_directory_index].present) {
        printf("Error: Page directory entry not present for virtual address 0x%x\n", virtual_address);
        return -1;
    }

    // 获取页表
    PageTable *pt = (PageTable *)(physical_memory + (pd->entries[page_directory_index].frame * PAGE_SIZE));

    // 查找页表项
    if (!pt->entries[page_table_index].present) {
        printf("Error: Page table entry not present for virtual address 0x%x\n", virtual_address);
        return -1;
    }

    // 计算物理地址
    *physical_address = (pt->entries[page_table_index].frame * PAGE_SIZE) + page_offset;
    return 0;
}

// 分配页
void alloc_pages(PageDirectory *pd, uint32_t virtual_address, uint32_t num_pages) {
    for (uint32_t i = 0; i < num_pages; i++) {
        uint32_t physical_page = alloc_page();
        if (physical_page == (uint32_t)-1) {
            printf("Error: Out of physical memory!\n");
            return;
        }
        map_page(pd, virtual_address + i * PAGE_SIZE, physical_page * PAGE_SIZE);
        printf("physical page %d for virtual page %d",physical_page,i);
    }
}

// 释放页
void free_pages(PageDirectory *pd, uint32_t virtual_address, uint32_t num_pages) {
    for (uint32_t i = 0; i < num_pages; i++) {
        unmap_page(pd, virtual_address + i * PAGE_SIZE);
        printf("free pages %d",i);
    }
}

int main() {
    // 初始化页目录
    PageDirectory *pd = alloc_page_directory();

    // 分配并映射虚拟地址到物理地址
    alloc_pages(pd, 0x12345000, 2);  // 分配两个页面从虚拟地址0x12345000开始

    // 测试虚拟地址到物理地址的转换
    uint32_t physical_address;
    if (virtual_to_physical(pd, 0x12345000, &physical_address) == 0) {
        printf("Virtual address 0x12345000 maps to physical address 0x%x\n", physical_address);
    }

    if (virtual_to_physical(pd, 0x12346000, &physical_address) == 0) {
        printf("Virtual address 0x12346000 maps to physical address 0x%x\n", physical_address);
    }

    // 释放分配的页面
    free_pages(pd, 0x12345000, 2);

    return 0;
}


