#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <stdlib.h>

#define PAGE_SIZE 4096           // 每页大小为 4KB
#define TOTAL_MEMORY 65536 * 4    // 64MB 的总内存，页面数量 * 4 倍（扩展为 256MB 供测试）
#define NUM_PAGES (TOTAL_MEMORY / PAGE_SIZE)   // 页数 = 总内存 / 每页大小

unsigned char bitmap[NUM_PAGES / 8];  // 位图，每 8 位表示 8 页
void *memory_pool;                    // 内存池，模拟整个内存
FILE *output_file;                    // 输出文件指针

// 初始化内存管理器
void init_memory_manager() 
{
    memset(bitmap, 0, sizeof(bitmap));  // 初始化位图为 0，表示所有页都空闲
    memory_pool = malloc(TOTAL_MEMORY); // 分配模拟的内存池
    if (!memory_pool) 
    {
        fprintf(output_file, "Memory allocation failed\n");
        exit(1);  // 如果无法分配内存，退出程序
    }
    fprintf(output_file, "Memory manager initialized with %d pages.\n", NUM_PAGES);
}

// 检查某一页是否被占用
bool is_page_allocated(int page_number) 
{
    int byte_index = page_number / 8;   // 位图中的字节索引
    int bit_offset = page_number % 8;   // 字节内的位偏移
    return (bitmap[byte_index] & (1 << bit_offset)) != 0;
}

// 标记某一页为分配状态
void allocate_page(int page_number) 
{
    int byte_index = page_number / 8;
    int bit_offset = page_number % 8;
    bitmap[byte_index] |= (1 << bit_offset);   // 将该位标记为 1，表示已分配
}

// 标记某一页为空闲状态
void free_page(int page_number) 
{
    int byte_index = page_number / 8;
    int bit_offset = page_number % 8;
    bitmap[byte_index] &= ~(1 << bit_offset);  // 将该位清 0，表示空闲
}

// 分配连续的 n 页内存
void *alloc_pages(int num_pages) 
{
    for (int i = 0; i < NUM_PAGES; i++) 
    {
        bool found = true;
        for (int j = 0; j < num_pages; j++) 
        {
            if (i + j >= NUM_PAGES || is_page_allocated(i + j)) 
            {
                found = false;  // 如果找到已分配的页，跳出循环
                break;
            }
        }

        if (found) 
        {  // 找到合适的连续页块
            for (int j = 0; j < num_pages; j++) 
            {
                allocate_page(i + j);  // 分配这些页
            }
            return (char*)memory_pool + i * PAGE_SIZE;  // 返回内存块的地址
        }
    }

    return NULL;  // 如果没有足够的连续空闲页，返回 NULL
}

// 释放已分配的页
void free_pages(void *addr, int num_pages) 
{
    int start_page = ((char*)addr - (char*)memory_pool) / PAGE_SIZE;  // 计算起始页号
    for (int i = 0; i < num_pages; i++) 
    {
        free_page(start_page + i);  // 释放这些页
    }
    fprintf(output_file, "Freed %d pages starting from page %d\n", num_pages, start_page);
}

// 打印当前位图状态
void print_bitmap() 
{
    fprintf(output_file, "Current bitmap (bit view):\n");
    for (int i = 0; i < NUM_PAGES / 8; i++) 
    {
        fprintf(output_file, "Byte %d: ", i);
        for (int bit = 7; bit >= 0; bit--) 
        {
            fprintf(output_file, "%d", (bitmap[i] >> bit) & 1);  // 打印每一位的状态
        }
        fprintf(output_file, "\n");
    }
    fprintf(output_file, "\n");
}

// 打印当前内存使用状态
void print_memory_status() 
{
    fprintf(output_file, "Memory usage:\n");
    for (int i = 0; i < NUM_PAGES; i++) 
    {
        fprintf(output_file, "Page %d: %s\n", i, is_page_allocated(i) ? "Allocated" : "Free");
    }
}

int main() 
{
    output_file = fopen("page.txt", "w");  // 打开输出文件
    if (!output_file) 
    {
        printf("Failed to open output file.\n");
        return 1;
    }

    init_memory_manager();           // 初始化内存管理器
    print_bitmap();                  // 打印初始位图状态

    void *p1 = alloc_pages(10);      // 分配 10 页
    fprintf(output_file, "Allocated 10 pages at %p\n", p1);
    print_bitmap();                  // 打印分配后的位图状态

    void *p2 = alloc_pages(5);       // 分配 5 页
    fprintf(output_file, "Allocated 5 pages at %p\n", p2);
    print_bitmap();                  // 打印分配后的位图状态

    print_memory_status();           // 打印内存状态

    free_pages(p1, 10);              // 释放 10 页
    print_bitmap();                  // 打印释放后的位图状态
    print_memory_status();           // 再次打印内存状态

    free_pages(p2, 5);               // 释放 5 页
    print_bitmap();                  // 打印释放后的位图状态
    print_memory_status();           // 再次打印内存状态

    fclose(output_file);             // 关闭文件
    system("pause");
    return 0;
}
