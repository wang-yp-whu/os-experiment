//this program aims to kill a process by its PID
#include "../include/ls.h"

int my_atoi(const char* str) 
{
    int result = 0;
    int sign = 1;

    while (*str >= '0' && *str <= '9') 
    {
        result = result * 10 + (*str - '0');
        str++;
    }

    return sign * result;
}

int main(int argc, char* argv[]) 
{
    if (argc < 2) 
    {
        printf("illegal command!!!\n");
        printf("please use the command in right format\n");
        return -1;
    }
    int pid = my_atoi(argv[1]);
    MESSAGE msg;
    msg.PID = pid;
    msg.type = END_WHICH_PROC; 
    send_recv(BOTH, TASK_SYS, &msg);
    printf("Process %d killed.\n", pid);
    return 0;
}
