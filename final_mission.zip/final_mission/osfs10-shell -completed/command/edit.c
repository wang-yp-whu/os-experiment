#include "ls.h"

typedef unsigned long ssize_t;
const char* cmd[] = {"echo", "ls", "pwd", "touch", "rm", "ps", "cat"};

int main(int args, char* argv[])
{
    if(args < 2)
    {
        printf("illegal commmand!!!\n");
		printf("please use the comamnd in right format\n");
        return 0;
    }
    if(strcmp(argv[1], cmd[0]) == 0)
    {
        //echo
        int i;
	    for (i = 2; i < args; i++)
		    printf("%s%s", i == 2 ? "" : " ", argv[i]);
	    printf("\n");
	    return 0;
    }

    else if(strcmp(argv[1], cmd[1]) == 0)
    {
        //ls
        // MESSAGE msg;
        // // 打开根目录
        // msg.type = OPEN;
        // msg.PATHNAME = "/";
        // msg.FLAGS = O_RDWR;   
        // msg.NAME_LEN = 1;    
        // // 打开根目录
        // int result = send_recv(BOTH, TASK_FS, &msg);
        // if (result != 0) 
        // {
        //     printf("Failed to open root directory.\n");
        //     return -1;
        // }
        // int fd = msg.FD;
        // char buf[SECTOR_SIZE];
        // msg.type = READ;
        // msg.FD = fd;
        // msg.BUF = buf;
        // msg.CNT = sizeof(buf);
        // msg.POSITION = 0;  
        // result = send_recv(BOTH, TASK_FS, &msg);
        // if (result != 0 || msg.CNT <= 0) 
        // {
        //     printf("Failed to read directory entries.\n");
        //     return -1;
        // }
        // struct dir_entry* pde = (struct dir_entry*)buf;
        // int nr_dir_entries = msg.CNT / DIR_ENTRY_SIZE;
        // for (int i = 0; i < nr_dir_entries; i++, pde++) 
        // {
        //     if (pde->inode_nr != 0) 
        //     {  
        //         printf("%s\n", pde->name);
        //     }
        // }
        // msg.type = CLOSE;
        // msg.FD = fd;
        // send_recv(BOTH, TASK_FS, &msg);
        // return 0;
        int fd = open(".", O_RDWR);
        if (fd == -1) 
        {
            printf("Failed to open root directory.\n");
            return 0;
        }
        struct dir_entry 
        {
            int inode_nr;
            char name[12];
        } dir_entries[64];
        int n = read(fd, dir_entries, sizeof(dir_entries));
        if (n == -1) 
        {
            printf("Failed to read root directory.\n");
            close(fd);
            return 0;
        }
        printf("Name    Size(byte)\n");
        for (int i = 0; i < n / sizeof(struct dir_entry); i++) 
        {
            if (dir_entries[i].inode_nr != 0) 
            {
                struct stat file_stat;
                if (stat(dir_entries[i].name, &file_stat) == 0) 
                {
                    printf("%s    %d\n", dir_entries[i].name, file_stat.st_size);
                } 
                else 
                {
                    printf("%s       Error\n", dir_entries[i].name);
                }
            }
        }
        close(fd);
        return 0;
    }

    else if(strcmp(argv[1], cmd[2]) == 0)
    {
        //pwd
        printf("/\n");
        return 0;
    }

    else if(strcmp(argv[1], cmd[3]) == 0)
    {
        //touch
        int fd = open(argv[2],O_CREAT);
        if(fd != -1)
        {
            printf("creat %s successfully\n",argv[2]);
        }
        else
        {
            printf("faile to creat %s\n",argv[2]);
        }
        return 0;
    }

    else if(strcmp(argv[1], cmd[4]) == 0)
    {
        //rm
        if(unlink(argv[2]) == -1)
		{
			printf("rm file failed\n");
			return -1;
		}
		printf("%s is successfully removed\n",argv[2]);
        return 0;
    }

    else if(strcmp(argv[1], cmd[5]) == 0)
    {
        //ps
        MESSAGE msg;
        struct proc p;
        printf("PID  NAME  FLAGS\n");
        int i=0;
        for (i = 0; i < NR_TASKS + NR_PROCS; i++) 
        {
            msg.PID = i;
            msg.type = GET_PROC_INFO;
            msg.BUF = &p;
            send_recv(BOTH, TASK_SYS, &msg);
            if (p.p_flags != FREE_SLOT) 
            {
                printf("%d    %s    ", i, p.name);
                printf("this is the %dth process\n", i);
            }
        }
        return 0;
    }

    else if(strcmp(argv[1], cmd[6]) == 0)
    {
        //cat
        int fd;
        char cat_buf[0x200];
        int i;
        printf("hello cat!\n");
        for(i = 2; i < args; i++)
        {
            fd = -1;
            fd = open(argv[i], O_RDWR);
            if(fd < 0)
            {
                printf("cat: %s: No such file or directory\n", argv[i]);			
            }
            else
            {
                read(fd, cat_buf, 0x200);
                write(1, cat_buf, 0x200);
                printf("\n");
                close(fd);
            }
        }
        return 0;
    }

    //此时不是可执行文件
    if (args == 2) 
    {
        // 打开文件，若不存在则创建
        int fd = open(argv[1], O_CREAT | O_RDWR);
        if (fd == -1) 
        {
            printf("Failed to create %s. Please check.\n", argv[1]);
            return 1;
        }
        printf("Successfully created %s.\n", argv[1]);
        close(fd);
        return 0;
    }
    if (args == 3) 
    {
        int fd = open(argv[1], O_RDWR | O_CREAT);
        if (fd == -1) 
        {
            printf("Failed to create %s. Please check.\n", argv[1]);
            return 1;
        }
        // 获取文本内容并写入文件
        const char *content = argv[2];
        ssize_t written = write(fd, content, strlen(content));
        if (written == -1) 
        {
            printf("Failed to write to %s.\n", argv[1]);
            close(fd);
            return 1;
        }
        printf("Successfully created %s and added content: %s\n", argv[1], content);
        close(fd);
        return 0;
    }
    return 0;
}
