//use touch to create a file in the current directory
# include "stdio.h"

int main(int args,char* argv[])
{
	if(args > 2)
	{
		printf("illegal command!!!\n");
		printf("please use the command in right format\n");
		return 0;
	}
	int fd = open(argv[1],O_CREAT);
	if(fd != -1)
	{
		printf("creat %s successfully\n",argv[1]);
	}
	else
	{

		printf("faile to creat %s\n",argv[1]);
	}
	
	return 0;
}
