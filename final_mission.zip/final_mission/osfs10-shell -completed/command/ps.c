#include "../include/ls.h"

int main(int argc, char* argv[]) 
{
    MESSAGE msg;
    struct proc p;
    printf("PID  NAME  FLAGS\n");
    int i=0;
    for (i = 0; i < NR_TASKS + NR_PROCS; i++) 
    {
        msg.PID = i;
        msg.type = GET_PROC_INFO;
        msg.BUF = &p;
        send_recv(BOTH, TASK_SYS, &msg);
        if (p.p_flags != FREE_SLOT) 
        {
	        printf("%d    %s",i,p.name);
            printf("this is the %dth process\n",i);
        }
    }
    return 0;
}
