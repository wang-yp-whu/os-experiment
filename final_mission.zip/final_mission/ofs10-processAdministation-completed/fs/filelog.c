// /*************************************************************************//**
//  *****************************************************************************
//  * @file   filelog.c
//  * @brief  
//  * @author STRELITZIA
//  * @date   24-12-11-00-21-20
//  *****************************************************************************
//  *****************************************************************************/

#include "type.h"
#include "config.h"
#include "stdio.h"
#include "const.h"
#include "protect.h"
#include "string.h"
#include "fs.h"
#include "proc.h"
#include "tty.h"
#include "console.h"
#include "global.h"
#include "keyboard.h"
#include "proto.h"
#include "hd.h"
#include "fs.h"

// reme to alter the Makefile!!  not finish

// things should be done in this file:
/*
    1st initialization - by set a static var flag(or anything else)
    2nd write          - which means the log content should be sent in by syslog_file at first
                       - receive string <-- write(fd, str, len(str))
    3rd should return the postion in the file? the pointer should be set, but thats later things. 
        preliminary return true.
*/

//
//  since fs cannot call itself, than it should call mm to help him record the cmd
//
// PUBLIC int do_send2mm(int pid, char * pname){
    
// 	MESSAGE do_send_msg;
// 	do_send_msg.type = FS_LOG;
//     do_send_msg.PID = pid;
//     do_send_msg.BUF = pname;
//     do_send_msg.FLAGS = 10086;
//     printl("11111111 in do_s2m\n");
// 	send_recv(SEND, TASK_MM, &do_send_msg);
//     // assert(do_send_msg.type == SYSCALL_RET);
//     printl("in send2mm, return SYSCALL\n");
// 	// assert(do_send_msg.RETVAL == 0);

// 	return 0;
// }



// #define MAX_BUF 512                     // read 1024 bytes

// char * log_file_name = "syslog";        // no '/

// PUBLIC int filelog(char * logstr){

// #ifdef ENABLE_FILE_LOG

//     // static int trigger = 1;
//     // static int init = 0;
    
//     printl("%s\n", logstr);

//     int buf_len = strlen(logstr)+25;
//     char filelogbuf[buf_len];
//         memset(filelog, ' ', buf_len);
//         // get time
//         struct time t;
//         MESSAGE msg;
//         msg.type = GET_RTC_TIME;
//         msg.BUF= &t;
//         send_recv(BOTH, TASK_SYS, &msg);

//         sprintf((char*)filelogbuf, "<%d-%02d-%02d %02d:%02d:%02d>\n",	// 21 (for time)
//             t.year,
//             t.month,
//             t.day,
//             t.hour,
//             t.minute,
//             t.second
//         );
//         filelogbuf[22] = ' ';
//         sprintf((char*)filelogbuf + 23, logstr);
//         int fd = open(log_file_name, O_RDWR);
//         if (lseek(fd, 0, SEEK_END) > 2048);
//             lseek(fd, 0, SEEK_SET);
//         write(fd, filelogbuf, 24+strlen(logstr));           // never write more ' ' into file, or the filesize will crash
//         close(fd);
// #endif

// #ifndef ENABLE_FILE_LOG
//     printf("log is closed!\n");
//     return -1;
// #endif

//     return 0;
// }