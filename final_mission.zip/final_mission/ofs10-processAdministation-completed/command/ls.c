#include "stdio.h"
#include "../include/sys/const.h"
#include "type.h"

int main(int argc, char *argv[]) {
    int fd = open(".", O_RDWR);
    if (fd == -1) {
        printf("Failed to open root directory.\n");
        return 0;
    }

    struct dir_entry {
        int inode_nr;
        char name[12];
    } dir_entries[64];

    int n = read(fd, dir_entries, sizeof(dir_entries));
    if (n == -1) {
        printf("Failed to read root directory.\n");
        close(fd);
        return 0;
    }

    printf("Name\t\tSize(byte)\n");
    for (int i = 0; i < n / sizeof(struct dir_entry); i++) {
        if (dir_entries[i].inode_nr != 0) {
            struct stat file_stat;
            if (stat(dir_entries[i].name, &file_stat) == 0) {
                printf("%s\t\t%d\n", dir_entries[i].name, file_stat.st_size);
            } else {
                printf("%s\t\tError\n", dir_entries[i].name);
            }
        }
    }

    close(fd);
    return 0;
}