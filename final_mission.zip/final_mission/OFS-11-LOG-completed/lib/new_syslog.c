// #include "type.h"
// #include "stdio.h"
// #include "const.h"
// #include "protect.h"
// #include "string.h"
// #include "fs.h"
// #include "proc.h"
// #include "tty.h"
// #include "console.h"
// #include "global.h"
// #include "proto.h"
// #include "config.h"

// /***
//  * 1.syslog_file  将日志数据等写入对应日志缓冲区
//  * 2.filelog    日志缓冲区满则写入文件
//  * 3.get_rtc_time_log  4.read_register_log 用于读取时间
// ***/

// char* log_file_name = "syslog";        // 之前用的是路径加了个'//'（模仿genlog）,但是寄了，不知道为什么？
// PRIVATE int read_register_log(char reg_addr);
// PRIVATE u32 get_rtc_time_log(struct time* t);

// // char filelogbuf[MAX_BUF];               // in filelog.c
// char tmp1[STR_DEFAULT_LEN];

// PUBLIC int syslog_file(int log_buf_flag, const char* fmt, ...)     // should be use to log, not for init（错误）
// {
//     int i;
//     char buf[STR_DEFAULT_LEN];
//     va_list arg = (va_list)((char*)(&fmt) + 4); /**
//                              * 4: size of `fmt' in
//                              *    the stack
//                              */
//     i = vsprintf(buf, fmt, arg);
//     assert(strlen(buf) == i);     //原文，未做改变

//     memcpy(tmp1, buf, STR_DEFAULT_LEN);    //buf->tmp1
//     int pos;
//     int log_len = strlen(buf);      // 添加的Log长度,虽说strlen少了个末尾，应该不影响
//     struct time t;
//     MESSAGE msg;

//     switch (log_buf_flag)
//     {
//         case MMLOG:                 // mm_log_bufpos
//             pos = mm_log_bufpos;
//             if ((pos + 24 + log_len) > MAX_LOG_BUF)
//             {     // if over limit, stop push things into buf, wait for filelog
//                 mm_buffull_flag = true;
//                 break;
//             }
//             get_rtc_time_log(&t);
//             sprintf((char*)mm_log_buf + pos, "<%d-%02d-%02d %02d:%02d:%02d>\n",	// 21 (for time)，在disklog.c中有类似
//                 t.year,
//                 t.month,
//                 t.day,
//                 t.hour,
//                 t.minute,
//                 t.second
//             );
//             memset(mm_log_buf + pos + 22, ' ', 1);
//             sprintf(mm_log_buf + pos + 23, buf);
//             mm_log_buf[pos + 23 + log_len] = '\n';
//             pos += 24 + log_len;
//             mm_log_bufpos = pos;
//             break;

//         case FSLOG:                                     // BUF len has some p
//             pos = fs_log_bufpos;
//             if ((pos + 24 + log_len) > MAX_LOG_BUF)
//             {     // if over limit, stop push things into buf, wait for filelog
//                 fs_buffull_flag = true;
//                 break;
//             }
//             get_rtc_time_log(&t);
//             sprintf((char*)fs_log_buf + pos, "<%d-%02d-%02d %02d:%02d:%02d>\n",	// 21 (for time)
//                 t.year,
//                 t.month,
//                 t.day,
//                 t.hour,
//                 t.minute,
//                 t.second
//             );
//             memset(fs_log_buf + pos + 22, ' ', 1);
//             sprintf(fs_log_buf + pos + 23, buf);
//             fs_log_buf[pos + 23 + log_len] = '\n';
//             pos += 24 + log_len;
//             fs_log_bufpos = pos;
//             break;

//         case SYSLOG:            // 有可能加不了时间
//             pos = sys_log_bufpos;
//             if ((pos + 24 + log_len) > MAX_LOG_BUF)
//             {     // if over limit, stop push things into buf, wait for filelog
//                 sys_buffull_flag = true;
//                 break;
//             }
//             get_rtc_time_log(&t);
//             sprintf((char*)sys_log_buf + pos, "<%d-%02d-%02d %02d:%02d:%02d>\n",	// 21 (for time)
//                 t.year,
//                 t.month,
//                 t.day,
//                 t.hour,
//                 t.minute,
//                 t.second
//             );
//             memset(sys_log_buf + pos + 22, ' ', 1);
//             sprintf(sys_log_buf + pos + 23, buf);
//             sys_log_buf[pos + 23 + log_len] = '\n';
//             pos += 24 + log_len;
//             sys_log_bufpos = pos;
//             break;
            
//         case HDLOG:
//             pos = hd_log_bufpos;
//             if ((pos + 24 + log_len) > MAX_LOG_BUF)
//             {     // if over limit, stop push things into buf, wait for filelog
//                 hd_buffull_flag = true;
//                 break;
//             }
//             get_rtc_time_log(&t);
//             sprintf((char*)hd_log_buf + pos, "<%d-%02d-%02d %02d:%02d:%02d>\n",	// 21 (for time)
//                 t.year,
//                 t.month,
//                 t.day,
//                 t.hour,
//                 t.minute,
//                 t.second
//             );
//             memset(hd_log_buf + pos + 22, ' ', 1);
//             sprintf(hd_log_buf + pos + 23, buf);
//             hd_log_buf[pos + 23 + log_len] = '\n';
//             pos += 24 + log_len;
//             hd_log_bufpos = pos;

//             break;
//         default:
//             assert(0);
//             break;
//     }
//     return 0;
// }

// PUBLIC int filelog(int log_buf_flag, char* file_name)
// {
// #ifdef ENABLE_FILE_LOG

//     char ch = 0x20;
//     int fd = open(file_name, O_RDWR);
//     lseek(fd, 0, SEEK_END);
//     switch (log_buf_flag) 
//     {
//         case MMLOG:
//             write(fd, mm_log_buf, mm_log_bufpos); //写日志（此时已满）进入文件 
//             memset(mm_log_buf, ch, mm_log_bufpos);
//             mm_log_bufpos = 0;
//             mm_buffull_flag = false;        // 完成后，将标志位复位
//             break;
//         case FSLOG:
//             write(fd, fs_log_buf, fs_log_bufpos);
//             memset(fs_log_buf, ch, fs_log_bufpos);
//             fs_log_bufpos = 0;
//             fs_buffull_flag = false;
//             break;
//         case SYSLOG:
//             write(fd, sys_log_buf, sys_log_bufpos);
//             memset(sys_log_buf, ch, sys_log_bufpos);
//             sys_log_bufpos = 0;
//             sys_buffull_flag = false;
//             break;
//         case HDLOG:
//             write(fd, hd_log_buf, hd_log_bufpos);
//             memset(hd_log_buf, ch, hd_log_bufpos);
//             hd_log_bufpos = 0;                      // write over, memset and back to zero
//             hd_buffull_flag = false;
//             break;
//     }
//     close(fd);

// #endif

//     return 0;
// }

// PRIVATE u32 get_rtc_time_log(struct time* t)
// {
//     // 读取时间
//     t->year = read_register_log(YEAR);
//     t->month = read_register_log(MONTH);
//     t->day = read_register_log(DAY);
//     t->hour = read_register_log(HOUR);
//     t->minute = read_register_log(MINUTE);
//     t->second = read_register_log(SECOND);

//     if ((read_register_log(CLK_STATUS) & 0x04) == 0) 
//     {
//         /* Convert BCD to binary (default RTC mode) */
//         t->year = BCD_TO_DEC(t->year);
//         t->month = BCD_TO_DEC(t->month);
//         t->day = BCD_TO_DEC(t->day);
//         t->hour = BCD_TO_DEC(t->hour);
//         t->minute = BCD_TO_DEC(t->minute);
//         t->second = BCD_TO_DEC(t->second);
//     }
//     // 年份加上2000
//     t->year += 2000;

//     return 0;
// }

// PRIVATE int read_register_log(char reg_addr)
// {
//     out_byte(CLK_ELE, reg_addr);//选择要读取的CMOS RAM 寄存器
//     // 从端口读取时间
//     return in_byte(CLK_IO);
// }